//Cluster.h
//====== Author: Lorenzo Graziotto, 1762218 ======

#ifndef Cluster_h
#define Cluster_h

#include "Deposit.h"
#include <list>

class Cluster : public Deposit {
	public:
		Cluster();
		virtual ~Cluster();

		double energy() const;
		Vector3D position() const;

		void add(Deposit* toAdd);
		void remove(Deposit* toRemove);

		friend std::ostream& operator<<(std::ostream& os, const Cluster& rhs);

		void print(const std::string& offset="") const;

	private:
		std::list<Deposit*> _deposits;
};
#endif
