//Deposit.h
//====== Author: Lorenzo Graziotto, 1762218 ======

#ifndef Deposit_h
#define Deposit_h

#include <iostream>
#include "Vector3D.h"
#include <string>

class Deposit {
	public:
		Deposit();
		Deposit(const double e, const Vector3D p);
		Deposit(const Deposit& toCopy);
		virtual ~Deposit() { };

		virtual double energy() const {return _energy; }
		virtual Vector3D position() const {return _position; }
		
		virtual void setEnergy(const double energy);
		virtual void setPosition(const Vector3D position);

		Deposit operator+(const Deposit& rhs) const;
		const Deposit& operator+=(const Deposit& rhs);

		friend std::ostream& operator<<(std::ostream& os, const Deposit& rhs);

		virtual void print(const std::string& offset="") const;

	private:
		double _energy;
		Vector3D _position;
};
#endif
