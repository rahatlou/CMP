#include "Vector3D.h"
#include "Cluster.h"
#include "Deposit.h"
#include <iostream>

int main() {

  Deposit d1(10., Vector3D(0,0,0) );
  Deposit d2(10., Vector3D(10,10,10) );

  Cluster c1;
  c1.add(&d1);

  Cluster c2;
  c2.add(&d2);
  c2.add(&c1);

  std::cout << d1 << "\n" << d2 << "\n" << c1 << "\n" << c2 << std::endl;

  std::cout << "===> Change energy of Deposit d2 will also change energy of Cluster c2" << std::endl;
  d2.setEnergy(100.);

  std::cout << d1 << "\n" << d2 << "\n" << c1 << "\n" << c2 << std::endl;


}
