//Cluster.cc
//====== Author: Lorenzo Graziotto, 1762218 ======

#include "Cluster.h"

Cluster::Cluster() : Deposit(0,Vector3D(0,0,0)) {
	_deposits.clear();
}

Cluster::~Cluster() { 
	_deposits.clear();
}

double Cluster::energy() const {
	double energy = 0.;
	for(std::list<Deposit*>::const_iterator it = _deposits.begin(); it != _deposits.end(); it++) {
		energy += (*it)->energy();
	}

	return energy;
}

Vector3D Cluster::position() const {
	Vector3D avgPosition(0,0,0);
	for(std::list<Deposit*>::const_iterator it = _deposits.begin(); it != _deposits.end(); it++) {
		avgPosition += (*it)->position()*(*it)->energy();
	}
	avgPosition = avgPosition / energy();

	return avgPosition;
}

void Cluster::add(Deposit* toAdd) {
	_deposits.push_back(toAdd);
	Vector3D newPosition = (Deposit::energy()*Deposit::position() + toAdd->energy()*toAdd->position()) / (Deposit::energy() + toAdd->energy());

}

void Cluster::remove(Deposit* toRemove) {
	_deposits.remove(toRemove);
	
	double newEnergy = Deposit::energy() - toRemove->energy();
	Vector3D newPosition = (Deposit::energy()*Deposit::position() - toRemove->energy()*toRemove->position()) / (newEnergy);
}

std::ostream& operator<<(std::ostream& os, const Cluster& rhs) {
	os << "Cluster:  Energy = " << rhs.energy() << " GeV, Position = " << rhs.position() << " cm" << std::endl;
	os << "   Contains " << rhs._deposits.size() << " deposits" << std::endl;

	return os;
}

void Cluster::print(const std::string& offset) const {
	std::cout << offset << "Cluster: Energy = " << energy() << " GeV, Position = " << position() << " cm" << std::endl;
	std::cout << offset <<"   Contains " << _deposits.size() << " deposits: " << std::endl;
	for(std::list<Deposit*>::const_iterator it = _deposits.begin(); it != _deposits.end(); it++) {
		(*it)->print(offset+"      ");
	}  
}
