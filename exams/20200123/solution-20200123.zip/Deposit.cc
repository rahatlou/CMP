//Deposit.cc
//====== Author: Lorenzo Graziotto, 1762218 ======

#include "Deposit.h"

Deposit::Deposit() {
	_energy = 0.;
	_position = Vector3D(0,0,0);
}

Deposit::Deposit(const double energy, const Vector3D position) {
	_energy = energy;
	_position = position;
}

Deposit::Deposit(const Deposit& toCopy) {
	_energy = toCopy.energy();
	_position = toCopy.position();
}

void Deposit::setEnergy(const double energy) {
	_energy = energy;
}

void Deposit::setPosition(const Vector3D position) {
	_position = position;
}

Deposit Deposit::operator+(const Deposit& rhs) const {
	double energy = _energy + rhs.energy();
	Vector3D position = (_position*_energy + rhs.position()*rhs.energy()) / (energy);

	return Deposit(energy, position);
}

const Deposit& Deposit::operator+=(const Deposit& rhs) {
	_position = (_position*_energy + rhs.position()*rhs.energy()) / (_energy + rhs.energy());
	_energy += rhs.energy();

	return *this;
}

std::ostream& operator<<(std::ostream& os, const Deposit& rhs) {
	os << "Deposit: Energy = " << rhs._energy << " GeV, Position = " << rhs._position << " cm";
	
	return os;
}

void Deposit::print(const std::string& offset) const {
	std::cout << offset << "Deposit: Energy = " << _energy << " GeV, Position = " << _position << " cm" << std::endl;
}
